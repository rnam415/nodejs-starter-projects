# 3 - Cloud Storage

This folder contains the sample code for the [Cloud Storage][step-3]
tutorial. Please refer to the tutorial for instructions on configuring, running,
and deploying this sample.

[step-3]: https://cloud.google.com/nodejs/getting-started/using-cloud-storage
